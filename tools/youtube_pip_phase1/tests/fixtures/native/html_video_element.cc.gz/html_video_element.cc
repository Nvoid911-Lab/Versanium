/*
 * Copyright (C) 2007, 2008, 2009, 2010 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE COMPUTER, INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "third_party/blink/renderer/core/html/media/html_video_element.h"

#include <memory>

#include "base/feature_list.h"
#include "base/functional/callback_helpers.h"
#include "base/metrics/histogram_functions.h"
#include "cc/layers/layer.h"
#include "cc/paint/paint_canvas.h"
#include "media/base/cdm_config.h"
#include "media/base/key_system_names.h"
#include "media/base/media_switches.h"
#include "media/base/video_frame.h"
#include "third_party/blink/public/common/features.h"
#include "third_party/blink/public/mojom/blob/blob.mojom-blink.h"
#include "third_party/blink/public/mojom/frame/frame.mojom-blink.h"
#include "third_party/blink/public/platform/web_fullscreen_video_status.h"
#include "third_party/blink/public/platform/web_media_player.h"
#include "third_party/blink/renderer/bindings/core/v8/v8_fullscreen_options.h"
#include "third_party/blink/renderer/bindings/core/v8/v8_image_bitmap_options.h"
#include "third_party/blink/renderer/core/ad_tracker/ad_tracker.h"
#include "third_party/blink/renderer/core/css/css_property_names.h"
#include "third_party/blink/renderer/core/dom/attribute.h"
#include "third_party/blink/renderer/core/dom/document.h"
#include "third_party/blink/renderer/core/dom/dom_exception.h"
#include "third_party/blink/renderer/core/dom/shadow_root.h"
#include "third_party/blink/renderer/core/execution_context/agent.h"
#include "third_party/blink/renderer/core/fileapi/blob.h"
#include "third_party/blink/renderer/core/fileapi/public_url_manager.h"
#include "third_party/blink/renderer/core/frame/local_dom_window.h"
#include "third_party/blink/renderer/core/frame/local_frame.h"
#include "third_party/blink/renderer/core/frame/local_frame_client.h"
#include "third_party/blink/renderer/core/frame/local_frame_view.h"
#include "third_party/blink/renderer/core/frame/picture_in_picture_controller.h"
#include "third_party/blink/renderer/core/frame/settings.h"
#include "third_party/blink/renderer/core/fullscreen/fullscreen.h"
#include "third_party/blink/renderer/core/html/media/media_custom_controls_fullscreen_detector.h"
#include "third_party/blink/renderer/core/html/media/media_remoting_interstitial.h"
#include "third_party/blink/renderer/core/html/media/media_video_visibility_tracker.h"
#include "third_party/blink/renderer/core/html/media/picture_in_picture_interstitial.h"
#include "third_party/blink/renderer/core/html/media/video_frame_callback_requester.h"
#include "third_party/blink/renderer/core/html/media/video_wake_lock.h"
#include "third_party/blink/renderer/core/html/parser/html_parser_idioms.h"
#include "third_party/blink/renderer/core/html_names.h"
#include "third_party/blink/renderer/core/imagebitmap/image_bitmap.h"
#include "third_party/blink/renderer/core/inspector/console_message.h"
#include "third_party/blink/renderer/core/intersection_observer/intersection_observer_entry.h"
#include "third_party/blink/renderer/core/layout/geometry/physical_rect.h"
#include "third_party/blink/renderer/core/layout/layout_image.h"
#include "third_party/blink/renderer/core/layout/layout_video.h"
#include "third_party/blink/renderer/core/layout/layout_view.h"
#include "third_party/blink/renderer/core/loader/document_loader.h"
#include "third_party/blink/renderer/core/loader/lazy_media_helper.h"
#include "third_party/blink/renderer/core/loader/resource/video_timing.h"
#include "third_party/blink/renderer/core/page/page.h"
#include "third_party/blink/renderer/core/paint/timing/paint_timing_detector.h"
#include "third_party/blink/renderer/platform/blob/blob_data.h"
#include "third_party/blink/renderer/platform/graphics/canvas_non_2d_resource_provider.h"
#include "third_party/blink/renderer/platform/graphics/canvas_snapshot_info.h"
#include "third_party/blink/renderer/platform/graphics/gpu/extensions_3d_util.h"
#include "third_party/blink/renderer/platform/graphics/gpu/shared_gpu_context.h"
#include "third_party/blink/renderer/platform/graphics/graphics_context.h"
#include "third_party/blink/renderer/platform/graphics/image_data_buffer.h"
#include "third_party/blink/renderer/platform/graphics/skia/skia_utils.h"
#include "third_party/blink/renderer/platform/graphics/video_frame_image_util.h"
#include "third_party/blink/renderer/platform/image-encoders/image_encoder_utils.h"
#include "third_party/blink/renderer/platform/instrumentation/use_counter.h"
#include "third_party/blink/renderer/platform/runtime_enabled_features.h"
#include "third_party/blink/renderer/platform/scheduler/public/event_loop.h"
#include "third_party/blink/renderer/platform/scheduler/public/page_scheduler.h"
#include "third_party/blink/renderer/platform/web_test_support.h"
#include "third_party/blink/renderer/platform/widget/frame_widget.h"
#include "third_party/blink/renderer/platform/wtf/text/string_utf8_adaptor.h"
#include "ui/gfx/geometry/size.h"

namespace blink {

namespace {
// Represents the visibility threshold to be used by the
// |visibility_tracker_|. Where visibility is defined as: intersecting
// with the viewport and not occluded by other html elements within the page,
// with the exception of MediaControls.
//
// An HTMLVideoElement with visibility greater or equal than a given area
// measured in square CSS pixels (`kVisibilityThreshold`) is considered visible,
// and not visible otherwise.
constexpr int kVisibilityThreshold = 10000;

constexpr base::TimeDelta kTemporaryResourceDeletionDelay = base::Seconds(3);

// If enabled, VideoTiming is held as a strong member of HTMLVideoElement.
BASE_FEATURE(kKeepVideoTimingAlive, base::FEATURE_ENABLED_BY_DEFAULT);

// These values are persisted to logs. Entries should not be renumbered and
// numeric values should never be reused.
//
// LINT.IfChange(PictureInPictureSizeConstraintResult)
enum class PictureInPictureSizeConstraintResult {
  kSizeConstraintMet = 0,
  kSizeConstraintNotMet = 1,
  kMaxValue = kSizeConstraintNotMet,
};
// LINT.ThenChange(//tools/metrics/histograms/metadata/media/enums.xml:PictureInPictureSizeConstraintResult)

}  // namespace

HTMLVideoElement::HTMLVideoElement(Document& document)
    : HTMLMediaElement(html_names::kVideoTag, document),
      cache_deleting_timer_(
          GetDocument().GetTaskRunner(TaskType::kInternalMedia),
          this,
          &HTMLVideoElement::ResetCache) {
  if (document.GetSettings()) {
    default_poster_url_ =
        AtomicString(document.GetSettings()->GetDefaultVideoPosterURL());
  }

  custom_controls_fullscreen_detector_ =
      MakeGarbageCollected<MediaCustomControlsFullscreenDetector>(*this);

  wake_lock_ = MakeGarbageCollected<VideoWakeLock>(*this);

  EnsureUserAgentShadowRoot();
  UpdateStateIfNeeded();
}

void HTMLVideoElement::Trace(Visitor* visitor) const {
  visitor->Trace(image_loader_);
  visitor->Trace(custom_controls_fullscreen_detector_);
  visitor->Trace(visibility_tracker_);
  visitor->Trace(wake_lock_);
  visitor->Trace(remoting_interstitial_);
  visitor->Trace(picture_in_picture_interstitial_);
  visitor->Trace(video_timing_);
  visitor->Trace(cache_deleting_timer_);
  Supplementable<HTMLVideoElement>::Trace(visitor);
  HTMLMediaElement::Trace(visitor);
}

bool HTMLVideoElement::HasPendingActivity() const {
  return HTMLMediaElement::HasPendingActivity() ||
         (image_loader_ && image_loader_->HasPendingActivity());
}

Node::InsertionNotificationRequest HTMLVideoElement::InsertedInto(
    ContainerNode& insertion_point) {
  if (insertion_point.isConnected()) {
    custom_controls_fullscreen_detector_->Attach();

    // Tag the element as an ad if it is being inserted into the DOM by an ad
    // script. Once tagged, the element remains tagged for its lifetime.
    //
    // We apply a monkey-patch exclusion heuristic to ensure we only tag
    // videos genuinely originating from ad code, avoiding analytics scripts
    // that proxy the call from the main content.
    if (LocalFrame* frame = GetDocument().GetFrame()) {
      if (AdTracker* ad_tracker = frame->GetAdTracker()) {
        AdTracker::AdScriptAncestry ad_script_ancestry;
        if (!IsAdRelated() &&
            ad_tracker->IsAdScriptInStack(
                AdTracker::StackType::kTopOnly,
                /*ignore_monkey_patch=*/
                AdTracker::MonkeyPatchableApi::kNodeAppendChild,
                &ad_script_ancestry)) {
          AdProvenance ad_provenance =
              !ad_script_ancestry.ancestry_chain.empty()
                  ? AdProvenance(ad_script_ancestry.ancestry_chain[0].id)
                  : NoProvenance{};
          SetIsAdRelated(std::move(ad_provenance));
        }
      }
    }
  }

  auto insertion_notification_request =
      HTMLMediaElement::InsertedInto(insertion_point);

  UpdateVideoAdTaggingIfNeeded();

  UpdateVideoVisibilityTracker();

  // For poster-only videos with loading=lazy that were created before being
  // inserted, start monitoring now that we're in the document.
  if (RuntimeEnabledFeatures::LazyLoadVideoAndAudioEnabled() &&
      poster_deferred_for_lazy_load_ &&
      GetLazyMediaLoadState() == LazyMediaLoadState::kNone &&
      !HasMediaSources() && GetDocument().GetFrame()) {
    SetLazyMediaLoadState(LazyMediaLoadState::kDeferred);
    LazyMediaHelper::StartMonitoring(this);
  }

  return insertion_notification_request;
}

void HTMLVideoElement::ReadyStateChanged() {
  HTMLMediaElement::ReadyStateChanged();
  UpdateVideoAdTaggingIfNeeded();
}

void HTMLVideoElement::UpdateVideoAdTaggingIfNeeded() {
  if (!HasVideo() || !isConnected()) {
    return;
  }
  if (getReadyState() >= kHaveMetadata) {
    if (LocalFrame* frame = GetDocument().GetFrame()) {
      bool is_ad = IsAdRelated() || frame->IsAdFrame();
      if (is_ad && !IsVideoAd()) {
        UpdateToVideoAd();
      }
    }
  }
}

void HTMLVideoElement::RemovedFrom(ContainerNode& insertion_point) {
  HTMLMediaElement::RemovedFrom(insertion_point);
  custom_controls_fullscreen_detector_->Detach();
  UpdateVideoVisibilityTracker();
  SetPersistentState(false);
}

void HTMLVideoElement::ContextDestroyed() {
  custom_controls_fullscreen_detector_->ContextDestroyed();
  UpdateVideoVisibilityTracker();
  HTMLMediaElement::ContextDestroyed();
}

bool HTMLVideoElement::LayoutObjectIsNeeded(const DisplayStyle& style) const {
  return HTMLElement::LayoutObjectIsNeeded(style);
}

LayoutObject* HTMLVideoElement::CreateLayoutObject(const ComputedStyle& style) {
  if (auto* content_image =
          DynamicTo<ImageContentData>(style.GetContentData())) {
    if (!content_image->GetImage()->ErrorOccurred()) {
      return LayoutObject::CreateObject(this, style);
    }
  }
  return MakeGarbageCollected<LayoutVideo>(this);
}

void HTMLVideoElement::AttachLayoutTree(AttachContext& context) {
  HTMLMediaElement::AttachLayoutTree(context);
  // Initiate loading of the poster image if a default poster image is
  // specified and no poster has been loaded (=> no ImageLoader created).
  if (!default_poster_url_.empty() && !image_loader_) {
    UpdatePosterImage();
  }
  if (image_loader_ && GetLayoutObject()) {
    image_loader_->OnAttachLayoutTree();
  }
}

void HTMLVideoElement::UpdatePosterImage() {
  if (RuntimeEnabledFeatures::LazyLoadVideoAndAudioEnabled()) {
    if (poster_deferred_for_lazy_load_) {
      return;
    }

    if (IsLazyLoadDeferred() || HasLazyLoadingAttribute()) {
      poster_deferred_for_lazy_load_ = true;
      return;
    }

    // Defer to microtask to ensure all attributes are parsed.
    if (!image_loader_) {
      GetDocument().GetAgent().event_loop()->EnqueueMicrotask(
          BindOnce(&HTMLVideoElement::UpdatePosterImageInternal,
                   WrapWeakPersistent(this)));
      return;
    }
  } else {
    if (!image_loader_) {
      image_loader_ = MakeGarbageCollected<HTMLImageLoader>(this);
    }
  }
  image_loader_->UpdateFromElement();
}

void HTMLVideoElement::UpdatePosterImageInternal() {
  if (RuntimeEnabledFeatures::LazyLoadVideoAndAudioEnabled() &&
      (poster_deferred_for_lazy_load_ || IsLazyLoadDeferred() ||
       HasLazyLoadingAttribute())) {
    poster_deferred_for_lazy_load_ = true;
    // For poster-only videos (no src), SelectMediaResource exits early without
    // starting lazy load monitoring. Start monitoring here so the poster loads
    // when the element becomes visible. Also set the deferred state so
    // LoadDeferredMediaIfNeeded doesn't return early.
    if (!HasMediaSources() && GetDocument().GetFrame()) {
      SetLazyMediaLoadState(LazyMediaLoadState::kDeferred);
      LazyMediaHelper::StartMonitoring(this);
    }
    return;
  }

  if (!image_loader_) {
    image_loader_ = MakeGarbageCollected<HTMLImageLoader>(this);
  }
  image_loader_->UpdateFromElement();
}

void HTMLVideoElement::OnLazyLoadResumed() {
  if (poster_deferred_for_lazy_load_) {
    poster_deferred_for_lazy_load_ = false;
    if (!image_loader_) {
      image_loader_ = MakeGarbageCollected<HTMLImageLoader>(this);
    }
    image_loader_->UpdateFromElement();
  }
}

void HTMLVideoElement::CollectStyleForPresentationAttribute(
    const QualifiedName& name,
    const AtomicString& value,
    HeapVector<CSSPropertyValue, 8>& style) {
  if (name == html_names::kWidthAttr) {
    AddHTMLLengthToStyle(style, CSSPropertyID::kWidth, value);
    const AtomicString& height = FastGetAttribute(html_names::kHeightAttr);
    if (height) {
      ApplyAspectRatioToStyle(value, height, style);
    }
  } else if (name == html_names::kHeightAttr) {
    AddHTMLLengthToStyle(style, CSSPropertyID::kHeight, value);
    const AtomicString& width = FastGetAttribute(html_names::kWidthAttr);
    if (width) {
      ApplyAspectRatioToStyle(width, value, style);
    }
  } else {
    HTMLMediaElement::CollectStyleForPresentationAttribute(name, value, style);
  }
}

bool HTMLVideoElement::IsPresentationAttribute(
    const QualifiedName& name) const {
  if (name == html_names::kWidthAttr || name == html_names::kHeightAttr) {
    return true;
  }
  return HTMLMediaElement::IsPresentationAttribute(name);
}

void HTMLVideoElement::ParseAttribute(
    const AttributeModificationParams& params) {
  if (params.name == html_names::kPosterAttr) {
    const KURL poster_image_url = PosterImageURL();
    // Load the poster if set, |VideoPainter| will decide whether to draw
    // it. Only create an ImageLoader if a non-empty URL is seen.
    if (image_loader_ || !poster_image_url.IsEmpty()) {
      UpdatePosterImage();
    }
    // Notify the player when the poster image URL changes.
    if (auto* wmp = GetWebMediaPlayer()) {
      wmp->SetPoster(poster_image_url);
    }
    // Media remoting and picture in picture doesn't show the original poster
    if (remoting_interstitial_) {
      remoting_interstitial_->OnPosterImageChanged();
    }
    if (picture_in_picture_interstitial_) {
      picture_in_picture_interstitial_->OnPosterImageChanged();
    }
  } else {
    HTMLMediaElement::ParseAttribute(params);
  }
}

unsigned HTMLVideoElement::videoWidth() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->NaturalSize().width();
  }
  return 0;
}

unsigned HTMLVideoElement::videoHeight() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->NaturalSize().height();
  }
  return 0;
}

gfx::Size HTMLVideoElement::videoVisibleSize() const {
  return GetWebMediaPlayer() ? GetWebMediaPlayer()->VisibleSize() : gfx::Size();
}

bool HTMLVideoElement::IsURLAttribute(const Attribute& attribute) const {
  return attribute.GetName() == html_names::kPosterAttr ||
         HTMLMediaElement::IsURLAttribute(attribute);
}

const AtomicString HTMLVideoElement::ImageSourceURL() const {
  const AtomicString& url = FastGetAttribute(html_names::kPosterAttr);
  if (!StripLeadingAndTrailingHtmlSpaces(url).empty()) {
    return url;
  }
  return default_poster_url_;
}

void HTMLVideoElement::UpdatePictureInPictureAvailability() {
  if (!web_media_player_) {
    return;
  }

  for (auto& observer : GetMediaPlayerObserverRemoteSet()) {
    observer->OnPictureInPictureAvailabilityChanged(SupportsPictureInPicture());
  }
}

void HTMLVideoElement::UpdateVideoFrameAvailability() {
  bool available = !IsEncrypted() && web_media_player_ &&
                   HasAvailableVideoFrame() && HasReadableVideoFrame();

  if (available == last_reported_video_frame_availability_) {
    return;
  }
  last_reported_video_frame_availability_ = available;

  for (auto& observer : GetMediaPlayerObserverRemoteSet()) {
    observer->OnVideoFrameAvailabilityChanged(available);
  }
}

// TODO(zqzhang): this callback could be used to hide native controls instead of
// using a settings. See `HTMLMediaElement::onMediaControlsEnabledChange`.
void HTMLVideoElement::SetPersistentState(bool persistent) {
  SetPersistentStateInternal(persistent);
  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->SetPersistentState(persistent);
  }
}

void HTMLVideoElement::SetPersistentStateInternal(bool persistent) {
  is_auto_picture_in_picture_ = persistent;

  if (persistent) {
    Element* fullscreen_element =
        Fullscreen::FullscreenElementFrom(GetDocument());
    // Only set the video in persistent mode if it is not using native controls
    // and is currently fullscreen.
    if (!fullscreen_element || IsFullscreen()) {
      return;
    }

    is_persistent_ = true;
    PseudoStateChanged(CSSSelector::kPseudoVideoPersistent);

    // The video is also marked as containing a persistent video to simplify the
    // internal CSS logic.
    for (Element* element = this; element && element != fullscreen_element;
         element = element->ParentOrShadowHostElement()) {
      element->SetContainsPersistentVideo(true);
    }
    fullscreen_element->SetContainsPersistentVideo(true);
  } else {
    if (!is_persistent_) {
      return;
    }

    is_persistent_ = false;
    PseudoStateChanged(CSSSelector::kPseudoVideoPersistent);

    Element* fullscreen_element =
        Fullscreen::FullscreenElementFrom(GetDocument());
    // If the page is no longer fullscreen, the full tree will have to be
    // traversed to make sure things are cleaned up.
    for (Element* element = this; element && element != fullscreen_element;
         element = element->ParentOrShadowHostElement()) {
      element->SetContainsPersistentVideo(false);
    }
    if (fullscreen_element) {
      fullscreen_element->SetContainsPersistentVideo(false);
    }
  }

  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->OnDisplayTypeChanged(GetDisplayType());
  }
}

void HTMLVideoElement::CreateVisibilityTrackerIfNeeded() {
  const bool autopip_video_heuristics_enabled =
      RuntimeEnabledFeatures::AutoPictureInPictureVideoHeuristicsEnabled();
  const bool encryption_media_occlusion_tracking_enabled =
      base::FeatureList::IsEnabled(media::kEncryptedMediaOcclusionTracking);

  // Exit if neither feature needs the tracker.
  if (!autopip_video_heuristics_enabled &&
      !encryption_media_occlusion_tracking_enabled) {
    return;
  }

  if (visibility_tracker_) {
    UpdateVideoVisibilityTracker();
    return;
  }

  MediaVideoVisibilityTracker::ReportContinuousVisibilityCb
      report_continuous_visibility_cb;
  if (autopip_video_heuristics_enabled) {
    // Callback used by |MediaVideoVisibilityTracker| to report whether |this|
    // meets/does not meet the visibility threshold (kVisibilityThreshold).
    report_continuous_visibility_cb = BindRepeating(
        &HTMLVideoElement::ReportVisibility, WrapWeakPersistent(this));
  }

  visibility_tracker_ = MakeGarbageCollected<MediaVideoVisibilityTracker>(
      *this, kVisibilityThreshold, std::move(report_continuous_visibility_cb));
  UpdateVideoVisibilityTracker();
}

void HTMLVideoElement::ReportVisibility(bool meets_visibility_threshold) {
  if (GetWebMediaPlayer()) {
    for (auto& observer : GetMediaPlayerObserverRemoteSet()) {
      observer->OnVideoVisibilityChanged(meets_visibility_threshold);
    }
  }
}

void HTMLVideoElement::OnCdmAttached(const media::CdmConfig& cdm_config) {
  if (!base::FeatureList::IsEnabled(media::kEncryptedMediaOcclusionTracking)) {
    return;
  }

  // Allow External Clear Key for testing purposes, as it is the primary way
  // we test the EME pipeline in browser tests but is not hardware secure.
  // TODO(crbug.com/514379948): When ECK uses the CdmCapability, we can
  // remove the IsExternalClearKey check, and mock ECK with hardware secure
  // codecs for testing purposes.
  if (!cdm_config.use_hw_secure_codecs &&
      !media::IsExternalClearKey(cdm_config.key_system)) {
    return;
  }

  // Need to create and attach the tracker for Encrypted Media Occlusion
  // tracking.
  CreateVisibilityTrackerIfNeeded();
  if (visibility_tracker_) {
    visibility_tracker_->RequestVisibilityRatio(BindOnce(
        &HTMLVideoElement::OnVisibilityRatioReport, WrapWeakPersistent(this)));
  }
}

void HTMLVideoElement::RequestSaveVideoFrame() {
  auto image = CreateStaticBitmapImage(
      /*size=*/std::nullopt, /*reinterpret_as_srgb=*/false,
      /*respect_orientation=*/kDoNotRespectImageOrientation);
  if (!image) {
    return;
  }
  auto data_buffer = ImageDataBuffer::Create(image);
  if (!data_buffer) {
    return;
  }

  ImageEncodingMimeType encoding_mime_type =
      ImageEncoderUtils::ToEncodingMimeType("image/png");

  Vector<unsigned char> png_bytes;
  if (!data_buffer->EncodeImage(encoding_mime_type, /*quality=*/0,
                                &png_bytes)) {
    return;
  }

  // TODO(crbug.com/515541028): Avoid copying the bytes here.
  Blob* blob = Blob::Create(base::span(png_bytes), "image/png");
  LocalDOMWindow* window = GetDocument().domWindow();
  CHECK(window);
  PublicURLManager& url_manager = window->GetPublicURLManager();
  String blob_url = url_manager.RegisterUrl(blob);

  mojo::PendingRemote<mojom::blink::BlobURLToken> blob_url_token;
  url_manager.ResolveAsBlobURLToken(
      KURL(blob_url), blob_url_token.InitWithNewPipeAndPassReceiver(),
      /*is_top_level_navigation=*/false);

  auto params = mojom::blink::DownloadURLParams::New();
  params->should_prompt_for_save_location = true;
  auto timestamp_ms = base::saturated_cast<uint32_t>(
      currentTime() * base::Time::kMillisecondsPerSecond);
  params->suggested_name =
      StrCat({"videoframe_", String::Number(timestamp_ms)});
  params->url = KURL(blob_url);
  params->blob_url_token = std::move(blob_url_token);

  if (GetDocument().GetFrame()) {
    GetDocument().GetFrame()->GetLocalFrameHostRemote().DownloadURL(
        std::move(params));
  }
}

void HTMLVideoElement::OnVisibilityRatioReport(double ratio) {
  if (GetWebMediaPlayer()) {
    GetWebMediaPlayer()->SetVisibilityRatioAtPlaybackStart(ratio);
  }
}

void HTMLVideoElement::ResetCache(TimerBase*) {
  snapshot_provider_.reset();
  cached_draw_info_.reset();
}

gfx::Size HTMLVideoElement::GetVisualSizeInDIPs() const {
  auto* layout_video = DynamicTo<LayoutVideo>(GetLayoutObject());
  LocalFrameView* view = GetDocument().View();
  gfx::Rect viewport_rect;
  if (layout_video && view) {
    const PhysicalRect content_rect = layout_video->ReplacedContentRect();
    viewport_rect = view->FrameToViewport(
        ToEnclosingRect(layout_video->LocalToAbsoluteRect(content_rect)));
  } else {
    viewport_rect = BoundsInWidget();
  }

  gfx::Size dip_size = viewport_rect.size();
  LocalFrame* frame = GetDocument().GetFrame();
  if (auto* widget = frame ? frame->GetWidgetForLocalRoot() : nullptr) {
    dip_size = widget->BlinkSpaceToEnclosedDIPs(viewport_rect).size();
  }

  return dip_size;
}

bool HTMLVideoElement::MeetsRequestEnterPictureInPictureSizeConstraint(
    const std::optional<gfx::Size>& min_size) const {
  if (!min_size.has_value()) {
    return true;
  }

  const gfx::Size visual_size = GetVisualSizeInDIPs();
  return visual_size.width() >= min_size->width() &&
         visual_size.height() >= min_size->height();
}

bool HTMLVideoElement::IsPersistent() const {
  return is_persistent_;
}

void HTMLVideoElement::OnPlay() {
  if (!video_has_played_) {
    video_has_played_ = true;
    UpdatePictureInPictureAvailability();
  }

  // The Video Visibility Tracker is shared by both Auto-PiP and Encrypted
  // Media Occlusion Tracking. In OnPlay(), we only want to initialize it
  // for AutoPictureInPictureVideoHeuristicsEnabled feature.
  //
  // For encrypted media, the tracker should only be created via
  // OnCdmAttached(). Initializing it here when only the
  // kEncryptedMediaOcclusionTracking feature is enabled would incorrectly
  // attach the tracker to clear videos.
  if (RuntimeEnabledFeatures::AutoPictureInPictureVideoHeuristicsEnabled()) {
    CreateVisibilityTrackerIfNeeded();
  }

  if (!RuntimeEnabledFeatures::VideoAutoFullscreenEnabled() ||
      FastHasAttribute(html_names::kPlaysinlineAttr)) {
    return;
  }

  EnterFullscreen();
}

void HTMLVideoElement::OnLoadStarted() {
  web_media_player_->BecameDominantVisibleContent(mostly_filling_viewport_);
}

void HTMLVideoElement::OnLoadFinished() {
  // If the player did a lazy load, it's expecting to be called when the
  // element actually becomes visible to complete the load.
  if (web_media_player_->DidLazyLoad() && !PotentiallyPlaying()) {
    player_lazy_load_intersection_observer_ = IntersectionObserver::Create(
        GetDocument(),
        BindRepeating(&HTMLVideoElement::OnIntersectionChangedForLazyLoad,
                      WrapWeakPersistent(this)),
        LocalFrameMetricsAggregator::kMediaIntersectionObserver,
        IntersectionObserver::Params{
            .thresholds = {IntersectionObserver::kMinimumThreshold}});
    player_lazy_load_intersection_observer_->observe(this);
  }

  UpdatePictureInPictureAvailability();
}

void HTMLVideoElement::UpdateVideoVisibilityTracker() {
  if (!visibility_tracker_) {
    return;
  }

  visibility_tracker_->UpdateVisibilityTrackerState();
}

void HTMLVideoElement::LogPictureInPictureSizeMetrics(
    bool meets_constraint) const {
  base::UmaHistogramEnumeration(
      "Media.PictureInPicture.SizeConstraintResult",
      meets_constraint
          ? PictureInPictureSizeConstraintResult::kSizeConstraintMet
          : PictureInPictureSizeConstraintResult::kSizeConstraintNotMet);

  const gfx::Size visual_size = GetVisualSizeInDIPs();
  if (visual_size.width() <= 0xFFFF && visual_size.width() >= 0 &&
      visual_size.height() <= 0xFFFF && visual_size.height() >= 0) {
    int32_t encoded_size = (visual_size.width() << 16) | visual_size.height();
    if (meets_constraint) {
      base::UmaHistogramSparse("Media.PictureInPicture.AllowedVideoEncodedSize",
                               encoded_size);
    } else {
      base::UmaHistogramSparse("Media.PictureInPicture.BlockedVideoEncodedSize",
                               encoded_size);
    }
  }
}

void HTMLVideoElement::RequestEnterPictureInPicture(
    const std::optional<gfx::Size>& min_size) {
  bool meets_constraint =
      MeetsRequestEnterPictureInPictureSizeConstraint(min_size);

  if (min_size.has_value()) {
    LogPictureInPictureSizeMetrics(meets_constraint);
  }

  if (!meets_constraint) {
    return;
  }

  PictureInPictureController::From(GetDocument())
      .EnterPictureInPicture(this, /*promise=*/nullptr);
}

void HTMLVideoElement::RequestMediaRemoting() {
  GetWebMediaPlayer()->RequestMediaRemoting();
}

void HTMLVideoElement::RequestVisibility(
    RequestVisibilityCallback request_visibility_cb) {
  if (!visibility_tracker_) {
    std::move(request_visibility_cb).Run(false);
    return;
  }

  visibility_tracker_->RequestVisibility(std::move(request_visibility_cb));
}

void HTMLVideoElement::PaintCurrentFrame(cc::PaintCanvas* canvas,
                                         const gfx::Rect& dest_rect,
                                         const cc::PaintFlags& flags,
                                         bool acquire_texture_backing) const {
  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->Paint(canvas, dest_rect, flags, acquire_texture_backing);
  }
}

bool HTMLVideoElement::HasAvailableVideoFrame() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->HasAvailableVideoFrame();
  }
  return false;
}

bool HTMLVideoElement::HasReadableVideoFrame() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->HasReadableVideoFrame();
  }
  return false;
}

void HTMLVideoElement::OnFirstFrame(base::TimeTicks frame_time,
                                    size_t bytes_to_first_frame) {
  DCHECK(GetWebMediaPlayer());
  has_received_first_frame_ = true;

  LayoutObject* layout_object = GetLayoutObject();
  // HasLocalBorderBoxProperties will be false in some cases, specifically
  // picture-in-picture video may return false here.
  if (layout_object &&
      layout_object->FirstFragment().HasLocalBorderBoxProperties()) {
    VideoTiming* video_timing = MakeGarbageCollected<VideoTiming>();
    video_timing->SetFirstVideoFrameTime(frame_time);
    video_timing->SetIsSufficientContentLoadedForPaint();
    video_timing->SetUrl(currentSrc());
    video_timing->SetContentSizeForEntropy(bytes_to_first_frame);
    video_timing->SetIsCorsSameOrigin(!WouldTaintOrigin());

    PaintTimingDetector::NotifyFirstVideoFrame(
        *layout_object, videoVisibleSize(), *video_timing,
        layout_object->FirstFragment().LocalBorderBoxProperties(),
        layout_object->AbsoluteBoundingBoxRect());

    if (base::FeatureList::IsEnabled(kKeepVideoTimingAlive)) {
      // Keep VideoTiming alive as a strong member so it isn't garbage collected
      // before being reported as LCP.
      video_timing_ = video_timing;
    }
  }

  MaybeEnterImmersivePictureInPicture();
  UpdateVideoFrameAvailability();

  LocalFrame* frame = GetDocument().GetFrame();
  bool is_ad = IsAdRelated() || (frame && frame->IsAdFrame());
  if (is_ad && GetWebMediaPlayer() && GetWebMediaPlayer()->IsHDR()) {
    UseCounter::Count(GetDocument(), WebFeature::kAdVideoHDR);
  }
}

void HTMLVideoElement::EnterFullscreen() {
  if (!IsFullscreen()) {
    FullscreenOptions* options = FullscreenOptions::Create();
    options->setNavigationUI(V8FullscreenNavigationUI::Enum::kHide);
    Fullscreen::RequestFullscreen(*this, options,
                                  FullscreenRequestType::kPrefixed);
  }
}

void HTMLVideoElement::DidEnterFullscreen() {
  UpdateControlsVisibility();

  if (GetDisplayType() == WebMediaPlayer::DisplayType::kVideoPictureInPicture &&
      !IsInAutoPIP()) {
    PictureInPictureController::From(GetDocument())
        .ExitPictureInPicture(this, nullptr);
  }

  if (auto* wmp = GetWebMediaPlayer()) {
    // FIXME: There is no embedder-side handling in web test mode.
    if (!WebTestSupport::IsRunningWebTest()) {
      wmp->EnteredFullscreen();
    }
    wmp->OnDisplayTypeChanged(GetDisplayType());
  }
}

void HTMLVideoElement::DidExitFullscreen() {
  UpdateControlsVisibility();

  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->ExitedFullscreen();
    wmp->OnDisplayTypeChanged(GetDisplayType());
  }

  if (RuntimeEnabledFeatures::VideoAutoFullscreenEnabled() &&
      !FastHasAttribute(html_names::kPlaysinlineAttr)) {
    pause();
  }
}

void HTMLVideoElement::DidMoveToNewDocument(Document& old_document) {
  if (image_loader_) {
    image_loader_->ElementDidMoveToNewDocument();
  }

  wake_lock_->ElementDidMoveToNewDocument();

  if (visibility_tracker_) {
    // Ensure that the |visibility_tracker_| is detached when |this| is moved to
    // a new document. Calling |ElementDidMoveToNewDocument| on the tracker at
    // this point prevents having the tracker attached to an old document. The
    // subsequent call to |UpdateVideoVisibilityTracker| will re-attach
    // the tracker to the new document if needed.
    visibility_tracker_->ElementDidMoveToNewDocument();
    UpdateVideoVisibilityTracker();
  }

  HTMLMediaElement::DidMoveToNewDocument(old_document);
  if (image_loader_ || FastHasAttribute(html_names::kPosterAttr)) {
    UpdatePosterImage();
  }
}

unsigned HTMLVideoElement::webkitDecodedFrameCount() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->DecodedFrameCount();
  }
  return 0;
}

void HTMLVideoElement::DidChangeIsInCanvasSubtree() {
  HTMLMediaElement::DidChangeIsInCanvasSubtree();
  if (IsInCanvasSubtree()) {
    UpdateLayoutObject();
    if (auto* wmp = GetWebMediaPlayer()) {
      wmp->RequestVideoFrameCallback();
    }
  }
}

unsigned HTMLVideoElement::webkitDroppedFrameCount() const {
  if (auto* wmp = GetWebMediaPlayer()) {
    return wmp->DroppedFrameCount();
  }
  return 0;
}

KURL HTMLVideoElement::PosterImageURL() const {
  StringView url = StripLeadingAndTrailingHtmlSpaces(ImageSourceURL());
  if (url.empty()) {
    return KURL();
  }
  return GetDocument().CompleteURL(url);
}

bool HTMLVideoElement::IsDefaultPosterImageURL() const {
  return ImageSourceURL() == default_poster_url_;
}

scoped_refptr<StaticBitmapImage> HTMLVideoElement::CreateStaticBitmapImage(
    std::optional<gfx::Size> size,
    bool reinterpret_as_srgb,
    RespectImageOrientationEnum respect_orientation) {
  auto* wmp = GetWebMediaPlayer();
  if (!wmp) {
    return nullptr;
  }

  scoped_refptr<media::VideoFrame> media_video_frame =
      wmp->GetCurrentFrameThenUpdate();
  media::PaintCanvasVideoRenderer* video_renderer =
      wmp->GetPaintCanvasVideoRenderer();

  if (!media_video_frame || !video_renderer || (size && size->IsEmpty())) {
    return nullptr;
  }

  viz::RasterContextProvider* raster_context_provider = nullptr;
  if (auto wrapper = SharedGpuContext::ContextProviderWrapper()) {
    raster_context_provider =
        wrapper->ContextProvider().RasterContextProvider();
  }

  const bool is_accelerated =
      ShouldCreateAcceleratedImages(raster_context_provider);
  const auto orientation_behavior =
      !is_accelerated && respect_orientation == kRespectImageOrientation
          ? VideoOrientationBehavior::kTagOrientation
          : VideoOrientationBehavior::kHardFlip;
  const auto color_space_interpretation =
      reinterpret_as_srgb ? VideoColorSpaceInterpretation::kReinterpretAsSRGB
                          : VideoColorSpaceInterpretation::kPreserve;

  auto required_provider_info = CreateSnapshotProviderInfoForVideoFrame(
      *media_video_frame, size, color_space_interpretation,
      orientation_behavior);

  bool cached_info_matches_required_info =
      cached_draw_info_ &&
      required_provider_info.Matches(cached_draw_info_.value());
  if (!cached_info_matches_required_info) {
    snapshot_provider_.reset();

    if (is_accelerated) {
      snapshot_provider_ = CanvasNon2DResourceProvider::Create(
          required_provider_info.size, required_provider_info.format,
          required_provider_info.alpha_type, required_provider_info.color_space,
          required_provider_info.hdr_metadata,
          SharedGpuContext::ContextProviderWrapper(),
          gpu::SHARED_IMAGE_USAGE_DISPLAY_READ);
      if (!snapshot_provider_) {
        return nullptr;
      }
    }

    cached_draw_info_ = required_provider_info;
  }
  cache_deleting_timer_.StartOneShot(kTemporaryResourceDeletionDelay,
                                     FROM_HERE);

  scoped_refptr<StaticBitmapImage> image;
  if (snapshot_provider_) {
    image = CreateAcceleratedImageFromVideoFrame(
        std::move(media_video_frame), snapshot_provider_.get(), video_renderer,
        orientation_behavior, color_space_interpretation);
  } else {
    image = CreateUnacceleratedImageFromVideoFrame(
        std::move(media_video_frame), cached_draw_info_.value(), video_renderer,
        orientation_behavior, color_space_interpretation);
  }

  if (image) {
    image->SetOriginClean(!WouldTaintOrigin());
  }
  return image;
}

scoped_refptr<Image> HTMLVideoElement::GetSourceImageForCanvas(
    SourceImageStatus* status,
    const gfx::SizeF&) {
  scoped_refptr<Image> snapshot = CreateStaticBitmapImage();
  if (!snapshot) {
    *status = kInvalidSourceImageStatus;
    return nullptr;
  }

  *status = kNormalSourceImageStatus;
  return snapshot;
}

bool HTMLVideoElement::WouldTaintOrigin() const {
  return !IsMediaDataCorsSameOrigin();
}

gfx::SizeF HTMLVideoElement::ElementSize(
    const gfx::SizeF&,
    const RespectImageOrientationEnum) const {
  return gfx::SizeF(videoWidth(), videoHeight());
}

ImageBitmapSourceStatus HTMLVideoElement::CheckUsability() const {
  if (!HasAvailableVideoFrame()) {
    return base::unexpected(ImageBitmapSourceError::kInvalid);
  }
  return base::ok();
}

ScriptPromise<ImageBitmap> HTMLVideoElement::CreateImageBitmap(
    ScriptState* script_state,
    std::optional<gfx::Rect> crop_rect,
    const ImageBitmapOptions* options,
    ExceptionState& exception_state) {
  if (getNetworkState() == HTMLMediaElement::kNetworkEmpty) {
    exception_state.ThrowDOMException(
        DOMExceptionCode::kInvalidStateError,
        "The provided element has not retrieved data.");
    return EmptyPromise();
  }
  return ImageBitmapSource::FulfillImageBitmap(
      script_state, MakeGarbageCollected<ImageBitmap>(this, crop_rect, options),
      options, exception_state);
}

void HTMLVideoElement::MediaRemotingStarted(
    const WebString& remote_device_friendly_name) {
  is_remote_rendering_ = true;
  remote_device_friendly_name_ = remote_device_friendly_name;
  OnRemotePlaybackMetadataChange();
  if (!remoting_interstitial_) {
    remoting_interstitial_ =
        MakeGarbageCollected<MediaRemotingInterstitial>(*this);
    ShadowRoot& shadow_root = EnsureUserAgentShadowRoot();
    shadow_root.InsertBefore(remoting_interstitial_, shadow_root.firstChild());
    HTMLMediaElement::AssertShadowRootChildren(shadow_root);
  }
  remoting_interstitial_->Show(remote_device_friendly_name);
}

void HTMLVideoElement::MediaRemotingStopped(int error_code) {
  is_remote_rendering_ = false;
  remote_device_friendly_name_.Reset();
  if (IsDisposing()) {
    return;
  }
  OnRemotePlaybackMetadataChange();
  if (remoting_interstitial_) {
    remoting_interstitial_->Hide(error_code);
  }
}

bool HTMLVideoElement::SupportsPictureInPicture() const {
  return PictureInPictureController::From(GetDocument())
             .IsElementAllowed(*this) ==
         PictureInPictureController::Status::kEnabled;
}

WebMediaPlayer::DisplayType HTMLVideoElement::GetDisplayType() const {
  if (is_auto_picture_in_picture_ ||
      PictureInPictureController::IsElementInPictureInPicture(this)) {
    return WebMediaPlayer::DisplayType::kVideoPictureInPicture;
  }

  if (PictureInPictureController::IsInDocumentPictureInPicture(this)) {
    return WebMediaPlayer::DisplayType::kDocumentPictureInPicture;
  }

  if (is_effectively_fullscreen_) {
    return WebMediaPlayer::DisplayType::kFullscreen;
  }

  return HTMLMediaElement::GetDisplayType();
}

bool HTMLVideoElement::IsInAutoPIP() const {
  return is_auto_picture_in_picture_;
}

void HTMLVideoElement::DidPlayerMediaPositionStateChange(
    double playback_rate,
    base::TimeDelta duration,
    base::TimeDelta position,
    bool end_of_media) {
  HTMLMediaElement::DidPlayerMediaPositionStateChange(playback_rate, duration,
                                                      position, end_of_media);

  if (PictureInPictureController::IsElementInPictureInPicture(this)) {
    PictureInPictureController::From(GetDocument())
        .OnMediaPositionStateChanged(
            media_session::mojom::blink::MediaPosition::New(
                playback_rate, duration, position, base::TimeTicks::Now(),
                end_of_media));
  }
}

void HTMLVideoElement::OnPictureInPictureStateChange() {
  if (GetDisplayType() != WebMediaPlayer::DisplayType::kVideoPictureInPicture ||
      IsInAutoPIP()) {
    return;
  }

  PictureInPictureController::From(GetDocument())
      .OnPictureInPictureStateChange();
}

void HTMLVideoElement::OnEnteredPictureInPicture() {
  if (!picture_in_picture_interstitial_) {
    picture_in_picture_interstitial_ =
        MakeGarbageCollected<PictureInPictureInterstitial>(*this);
    ShadowRoot& shadow_root = EnsureUserAgentShadowRoot();
    shadow_root.InsertBefore(picture_in_picture_interstitial_,
                             shadow_root.firstChild());
    HTMLMediaElement::AssertShadowRootChildren(shadow_root);
  }
  picture_in_picture_interstitial_->Show();

  PseudoStateChanged(CSSSelector::kPseudoPictureInPicture);

  DCHECK(GetWebMediaPlayer());
  GetWebMediaPlayer()->OnDisplayTypeChanged(GetDisplayType());
}

void HTMLVideoElement::OnExitedPictureInPicture() {
  if (picture_in_picture_interstitial_) {
    picture_in_picture_interstitial_->Hide();
  }

  PseudoStateChanged(CSSSelector::kPseudoPictureInPicture);

  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->OnDisplayTypeChanged(GetDisplayType());
  }
}

void HTMLVideoElement::SetIsEffectivelyFullscreen(
    blink::WebFullscreenVideoStatus status) {
  const bool was_effectively_fullscreen = is_effectively_fullscreen_;
  is_effectively_fullscreen_ =
      status != blink::WebFullscreenVideoStatus::kNotEffectivelyFullscreen;
  if (auto* wmp = GetWebMediaPlayer()) {
    for (auto& observer : GetMediaPlayerObserverRemoteSet()) {
      observer->OnMediaEffectivelyFullscreenChanged(status);
    }

    wmp->SetIsEffectivelyFullscreen(status);
    wmp->OnDisplayTypeChanged(GetDisplayType());
  }

  if (is_effectively_fullscreen_ != was_effectively_fullscreen) {
    if (Page* page = GetDocument().GetPage()) {
      if (PageScheduler* page_scheduler = page->GetPageScheduler()) {
        page_scheduler->SetIsFullscreenVideo(is_effectively_fullscreen_);
      }
    }
  }

  // If the video becomes effectively fullscreen, enter an immersive
  // Picture-in-Picture session if enabled.
  if (is_effectively_fullscreen_ && !was_effectively_fullscreen) {
    MaybeEnterImmersivePictureInPicture();
  }
}

void HTMLVideoElement::MaybeEnterImmersivePictureInPicture() {
  if (!is_effectively_fullscreen_ || !has_received_first_frame_) {
    return;
  }
  if (GetDocument().GetSettings() &&
      GetDocument().GetSettings()->GetImmersiveVideoPlaybackEnabled()) {
    if (!PictureInPictureController::IsElementInPictureInPicture(this)) {
      PictureInPictureController::From(GetDocument())
          .EnterPictureInPictureImmersive(*this);
    }
  }
}

void HTMLVideoElement::SetIsDominantVisibleContent(bool is_dominant) {
  if (mostly_filling_viewport_ != is_dominant) {
    mostly_filling_viewport_ = is_dominant;
    auto* player = GetWebMediaPlayer();
    if (player) {
      player->BecameDominantVisibleContent(mostly_filling_viewport_);
    }

    auto* local_frame_view = GetDocument().View();
    if (local_frame_view) {
      local_frame_view->NotifyVideoIsDominantVisibleStatus(this, is_dominant);
    }
  }
}

void HTMLVideoElement::AddedEventListener(
    const AtomicString& event_type,
    RegisteredEventListener& registered_listener) {
  if (event_type == event_type_names::kEnterpictureinpicture) {
    UseCounter::Count(GetExecutionContext(),
                      WebFeature::kEnterPictureInPictureEventListener);
  } else if (event_type == event_type_names::kLeavepictureinpicture) {
    UseCounter::Count(GetExecutionContext(),
                      WebFeature::kLeavePictureInPictureEventListener);
  }

  HTMLMediaElement::AddedEventListener(event_type, registered_listener);
}

bool HTMLVideoElement::IsRemotingInterstitialVisible() const {
  return remoting_interstitial_ && remoting_interstitial_->IsVisible();
}

void HTMLVideoElement::OnIntersectionChangedForLazyLoad(
    const HeapVector<Member<IntersectionObserverEntry>>& entries) {
  bool is_visible = (entries.back()->intersectionRatio() > 0);
  if (!is_visible || !web_media_player_) {
    return;
  }

  player_lazy_load_intersection_observer_->disconnect();
  player_lazy_load_intersection_observer_ = nullptr;

  auto notify_visible = [](HTMLVideoElement* self) {
    if (self && self->web_media_player_) {
      self->web_media_player_->OnBecameVisible();
    }
  };

  GetDocument()
      .GetTaskRunner(TaskType::kInternalMedia)
      ->PostTask(FROM_HERE, BindOnce(notify_visible, WrapWeakPersistent(this)));
}

void HTMLVideoElement::OnWebMediaPlayerCreated() {
  if (auto* vfc_requester = VideoFrameCallbackRequester::From(*this)) {
    vfc_requester->OnWebMediaPlayerCreated();
  }

  if (IsCanvasOrInCanvasSubtree()) {
    if (auto* wmp = GetWebMediaPlayer()) {
      wmp->RequestVideoFrameCallback();
    }
  }
}

void HTMLVideoElement::OnWebMediaPlayerCleared() {
  has_received_first_frame_ = false;
  if (auto* vfc_requester = VideoFrameCallbackRequester::From(*this)) {
    vfc_requester->OnWebMediaPlayerCleared();
  }

  UpdateVideoVisibilityTracker();

  UpdateVideoFrameAvailability();
}

void HTMLVideoElement::RecordVideoOcclusionState(
    std::string_view occlusion_state) const {
  if (auto* wmp = GetWebMediaPlayer()) {
    wmp->RecordVideoOcclusionState(occlusion_state);
  }
}

void HTMLVideoElement::AttributeChanged(
    const AttributeModificationParams& params) {
  HTMLElement::AttributeChanged(params);

  if (params.name != html_names::kDisablepictureinpictureAttr) {
    return;
  }

  UpdatePictureInPictureAvailability();

  if (params.new_value.IsNull()) {
    return;
  }

  PictureInPictureController& controller =
      PictureInPictureController::From(GetDocument());
  if (controller.PictureInPictureElement(GetTreeScope()) == *this) {
    controller.ExitPictureInPicture(this, nullptr);
  }
}

void HTMLVideoElement::OnRequestVideoFrameCallback() {
  if (auto* vfc_requester = VideoFrameCallbackRequester::From(*this)) {
    vfc_requester->OnRequestVideoFrameCallback();
  }

  if (IsCanvasOrInCanvasSubtree()) {
    if (GetLayoutObject()) {
      GetLayoutObject()->SetShouldDoFullPaintInvalidation();
    }
    if (auto* wmp = GetWebMediaPlayer()) {
      wmp->RequestVideoFrameCallback();
    }
  }
}

void HTMLVideoElement::SetCcLayer(cc::Layer* cc_layer) {
  HTMLMediaElement::SetCcLayer(cc_layer);
  if (auto* layer = CcLayer()) {
    layer->SetFilterQuality(filter_quality_);
    layer->SetDynamicRangeLimit(dynamic_range_limit_);
  }
}

void HTMLVideoElement::StyleDidChange(const ComputedStyle* old_style,
                                      const ComputedStyle& new_style) {
  const auto new_filter_quality =
      (new_style.ImageRendering() == EImageRendering::kPixelated ||
       new_style.ImageRendering() == EImageRendering::kCrispEdges)
          ? cc::PaintFlags::FilterQuality::kNone
          : cc::PaintFlags::FilterQuality::kLow;
  const auto new_dynamic_range_limit = new_style.GetDynamicRangeLimit();
  if (filter_quality_ != new_filter_quality ||
      dynamic_range_limit_ != new_dynamic_range_limit) {
    filter_quality_ = new_filter_quality;
    dynamic_range_limit_ = new_dynamic_range_limit;
    if (auto* layer = CcLayer()) {
      layer->SetFilterQuality(filter_quality_);
      layer->SetDynamicRangeLimit(dynamic_range_limit_);
    }
  }
}

}  // namespace blink
